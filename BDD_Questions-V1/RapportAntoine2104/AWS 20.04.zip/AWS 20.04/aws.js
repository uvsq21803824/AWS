
const express = require("express");
const mysql = require('mysql');
const myConnection = require('express-myconnection');

const optionBd = {
	host: "bq5rywc2xtbyepjftd9f-mysql.services.clever-cloud.com",
	user: "ukyvpr3wzxsjmwov",
	password: "mCEQz4NfchflIPQNfiQI",
	port : 3306,
	database : 'bq5rywc2xtbyepjftd9f'
}

const app = express();

app.use(myConnection(mysql,optionBd,'pool'));

app.set("view engine","ejs");
app.set("views","IHM");



app.get("/", (req, res) => {
	
	req.getConnection((erreur,connection)=>{
		if(erreur){
			console.log(erreur);
		} else{
			connection.query('SELECT * FROM question', [], (erreur, q) =>{
				connection.query('SELECT * FROM difficulty', [], (erreur, d) =>{
					connection.query('SELECT * FROM genre', [], (erreur, g) =>{
						if(erreur) {
							console.log(erreur);
						}else {
							res.status(200).render("question", {q,d,g});
						}
					})
				})
			})
		}
	});
});

app.listen(3000);
console.log("Ouvert sur localhost:3000");
